import { auth } from '@/app/(auth)/auth';
import { NextResponse } from 'next/server';

const PRIVATE_INTEGRATION_API_URL = process.env.PRIVATE_INTEGRATION_API_URL || 'https://api.gohighlevel.com/v1/conversations/';
const PRIVATE_INTEGRATION_API_KEY = process.env.PRIVATE_INTEGRATION_API_KEY;

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) {
    return new Response('Unauthorized', { status: 401 });
  }

  try {
    const body = await req.json();
    const { messages, modelId } = body;

    const response = await fetch(PRIVATE_INTEGRATION_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${PRIVATE_INTEGRATION_API_KEY}`,
      },
      body: JSON.stringify({
        messages,
        model: modelId,
        userId: session.user.id,
      }),
    });

    const data = await response.json();
    return NextResponse.json(data);
  } catch (error) {
    console.error('Error in private integration API:', error);
    return new Response('Internal Server Error', { status: 500 });
  }
}