'use client';

import { useState } from 'react';
import { Message } from 'ai';

export function Chat({
  id,
  initialMessages = [],
  selectedModelId,
  selectedVisibilityType,
  isReadonly,
}) {
  const [messages, setMessages] = useState(initialMessages);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (userMessage: string) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/private-chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: [...messages, { role: 'user', content: userMessage }],
          modelId: selectedModelId,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to send message');
      }

      const data = await response.json();
      setMessages(prev => [...prev, 
        { role: 'user', content: userMessage },
        { role: 'assistant', content: data.response }
      ]);
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto">
        {messages.map((message, index) => (
          <div key={index} className={`p-4 ${message.role === 'user' ? 'bg-gray-100' : 'bg-white'}`}>
            {message.content}
          </div>
        ))}
      </div>
      {!isReadonly && (
        <div className="p-4 border-t">
          <form onSubmit={(e) => {
            e.preventDefault();
            const input = e.currentTarget.elements.namedItem('message') as HTMLInputElement;
            handleSubmit(input.value);
            input.value = '';
          }}>
            <input
              type="text"
              name="message"
              placeholder="Type your message..."
              className="w-full p-2 border rounded"
              disabled={isLoading}
            />
          </form>
        </div>
      )}
    </div>
  );
}